/*
Gabriel Lopes
gabriel18.lopes@gmail.com
semi 5 tabela hash
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define tamanho_tabela 225

typedef struct Dados{

    long int codigo;
    char descricao[30];
    double valor;


}dados;

typedef struct tabela {

    int bit_validade;

   dados *dados ;

}tabela;

tabela *inicio;

void iniciar_tabela(){
    int i;

    inicio = malloc (sizeof (tabela )*tamanho_tabela);

    for(i=0;i<tamanho_tabela;i++){


    inicio[i].dados=malloc(sizeof(dados));
   inicio[i].bit_validade=0;


    }


}
void inserir (){

int k;
dados *aux1;

aux1=malloc(sizeof(dados));

printf("\n Digite o codigo de insercao:");
scanf("%d",&aux1->codigo);

k=(aux1->codigo)*0.332;
k=tamanho_tabela*(((aux1->codigo)*0.332)-k);

    __fpurge(stdin);
    printf("\n Digite a descricao:");
    gets(aux1->descricao);
 __fpurge(stdin);
    printf("\n Digite o valor:");
    scanf("%lf",&aux1->valor);



    if(inicio[k].bit_validade == 0){

    inicio[k].dados=aux1;
    inicio[k].bit_validade=1;
    }
    else{
        int j = k;
        int a = 6;

    while(inicio[j].bit_validade!=1){

    j=j+a;
    if(j>tamanho_tabela-1){
    j=j-tamanho_tabela;// se o j passar do tamanho da tabela pulando voltar para o come;o

    }

    if(j=k){

    a=a-2;// se j = k quer dizer que voltou para o come;o , logo tratar diminuindo o fator de pulo

    if(a=0){

    printf("\n Tabela lotada ERRO \n");

    return 1;

    }
    }

    }
        inicio[j].dados=aux1;
        inicio[j].bit_validade=1;


    }

}




void consultar_1 (){
int k;
dados *aux1;
    aux1=malloc(sizeof(dados));

    __fpurge(stdin);
    printf("\n Digite o codigo da busca:");
    scanf("%d",&aux1->codigo);


k=(aux1->codigo)*0.332;
k=tamanho_tabela*(((aux1->codigo)*0.332)-k);


        if(inicio[k].bit_validade == 0){

        printf("\nERRO arquivo nao encontrado\n");
        return 0;

    }
    else{
        int j = k;
        int a = 6;

    while(inicio[j].dados->codigo!=aux1->codigo){

    j=j+a;
    if(j>tamanho_tabela-1){
    j=j-tamanho_tabela;// se o j passar do tamanho da tabela pulando voltar para o come;o

    }

    if(j=k){

    a=a-2;// se j = k quer dizer que voltou para o come;o , logo tratar diminuindo o fator de pulo

    if(a=0){

    printf("\n item nao encontrado ERRO \n");

    return 1;

    }
    }

    }
    printf("\n Valor:%.2f \n \t Descricao:",inicio[j].dados->valor);
    puts(inicio[j].dados->descricao);


    }

}

void consultar_tudo(){
dados *aux0;
int i;


for(i=0;i<tamanho_tabela;i++){


    if(inicio[i].bit_validade == 1){
    printf("\n Valor:%.2f \n \t Descricao:",inicio[i].dados->valor);
    puts(inicio[i].dados->descricao);
}

}

}


int main(){

        iniciar_tabela ();

    char a;
for(;;){
 __fpurge(stdin);
    printf("\n 1 inserir \n 2 consultar \n 3 exibir \n 4 encerrar \n ::: ");
        scanf("%c",&a);

switch(a){


    case '1':

    inserir();
    break;
    case '2':
    consultar_1 ();

    break;
    case '3':
    consultar_tudo ();

    break;
    case '4':
    free(inicio);
    return 0;
    break;


}
}

}
