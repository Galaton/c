



void criar_ram(int numero_de_palavras);
void visualizacao_completa_ram();
void criar_cache(int numero_de_palavras,int numero_vias);
void visualizacao_completa_cache(int numero_vias);
void visualizacao_faixa_de_endereco_cache(int numero_vias);
void cindex(int numero_conjuntos,float capacidade_de_dados_ram,int numero_de_palavras);

void criar_tld();
void criar_memoria_virtual();
